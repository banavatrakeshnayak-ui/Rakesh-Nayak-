import React, { useState } from 'react';
import { Copy, FileText, Wand2, Check, PenTool, LayoutTemplate } from 'lucide-react';
import { summarizeNotes } from '../services/geminiService';
import MarkdownRenderer from './MarkdownRenderer';
import VoiceInput from './VoiceInput';

const NotesInterface: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [summary, setSummary] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSummarize = async () => {
    if (!inputText.trim() || isGenerating) return;
    
    setIsGenerating(true);
    const result = await summarizeNotes(inputText);
    setSummary(result);
    setIsGenerating(false);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(summary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleVoiceInput = (text: string) => {
    setInputText(prev => {
      const trimmed = prev.trim();
      return trimmed ? `${trimmed} ${text}` : text;
    });
  };

  return (
    <div className="h-full bg-slate-50 flex flex-col md:flex-row overflow-hidden">
      
      {/* Left Panel: Input */}
      <div className="flex-1 flex flex-col h-full border-r border-slate-200 bg-white">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2 text-slate-700 font-semibold">
            <PenTool size={18} />
            <h2>Source Text</h2>
          </div>
          <VoiceInput onInput={handleVoiceInput} compact />
        </div>
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Paste lecture notes, essay drafts, or article text here..."
          className="flex-1 w-full p-6 outline-none resize-none text-slate-700 leading-relaxed font-sans placeholder-slate-300 text-sm md:text-base"
        />
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-between items-center">
          <span className="text-xs text-slate-400">{inputText.length} characters</span>
          <button
            onClick={handleSummarize}
            disabled={!inputText.trim() || isGenerating}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-medium transition-all shadow-sm ${
              !inputText.trim() || isGenerating
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-primary-600 to-primary-500 text-white hover:shadow-md hover:-translate-y-0.5'
            }`}
          >
            {isGenerating ? (
              <>
                <Wand2 size={16} className="animate-spin" />
                <span>Magic in progress...</span>
              </>
            ) : (
              <>
                <Wand2 size={16} />
                <span>Summarize</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Right Panel: Output */}
      <div className="flex-1 flex flex-col h-full bg-slate-50 relative overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2 text-primary-700 font-semibold">
            <LayoutTemplate size={18} />
            <h2>AI Summary</h2>
          </div>
          {summary && (
            <button
              onClick={copyToClipboard}
              className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 bg-primary-50 text-primary-700 rounded-lg hover:bg-primary-100 transition-colors"
            >
              {copied ? <Check size={14} /> : <Copy size={14} />}
              {copied ? 'Copied' : 'Copy Text'}
            </button>
          )}
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 md:p-8">
          {summary ? (
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 md:p-8 min-h-full">
               <MarkdownRenderer content={summary} className="prose-primary" />
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4 opacity-60">
              <FileText size={48} className="stroke-1" />
              <p className="text-sm font-medium">Your summary will appear here</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NotesInterface;