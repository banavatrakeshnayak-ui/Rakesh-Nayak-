import React, { useRef, useState, useCallback, useEffect } from 'react';
import { Camera, X, RefreshCw } from 'lucide-react';

interface CameraCaptureProps {
  onCapture: (base64Image: string) => void;
  onClose: () => void;
}

const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } // Prefer back camera on mobile
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsStreaming(true);
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      setError("Could not access camera. Please check permissions.");
    }
  };

  const stopCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setIsStreaming(false);
    }
  }, []);

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      // Set canvas dimensions to match video
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageBase64 = canvas.toDataURL('image/jpeg', 0.8);
        onCapture(imageBase64);
        stopCamera();
      }
    }
  };

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center">
      {/* Header controls */}
      <div className="absolute top-4 right-4 z-10">
        <button onClick={() => { stopCamera(); onClose(); }} className="p-2 bg-white/20 rounded-full text-white backdrop-blur-sm">
          <X size={24} />
        </button>
      </div>

      {/* Video Viewport */}
      <div className="relative w-full max-w-md h-full max-h-[80vh] bg-black flex items-center justify-center overflow-hidden rounded-lg">
        {!error ? (
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            className="w-full h-full object-cover"
            onLoadedMetadata={() => setIsStreaming(true)}
          />
        ) : (
          <div className="text-white text-center p-4">
            <p>{error}</p>
            <button 
              onClick={startCamera} 
              className="mt-4 px-4 py-2 bg-blue-600 rounded-lg text-white"
            >
              Retry
            </button>
          </div>
        )}
        <canvas ref={canvasRef} className="hidden" />
      </div>

      {/* Footer controls */}
      <div className="absolute bottom-8 left-0 right-0 flex justify-center items-center gap-8">
        <button 
          onClick={captureImage}
          disabled={!isStreaming}
          className={`w-16 h-16 rounded-full border-4 border-white flex items-center justify-center ${isStreaming ? 'bg-white/20' : 'bg-gray-500 opacity-50 cursor-not-allowed'}`}
        >
          <div className="w-12 h-12 bg-white rounded-full"></div>
        </button>
      </div>
    </div>
  );
};

export default CameraCapture;
