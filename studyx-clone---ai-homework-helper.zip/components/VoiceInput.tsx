import React, { useState, useEffect } from 'react';
import { Mic, MicOff } from 'lucide-react';

interface VoiceInputProps {
  onInput: (text: string) => void;
  className?: string;
  compact?: boolean;
}

const VoiceInput: React.FC<VoiceInputProps> = ({ onInput, className, compact = false }) => {
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      // @ts-ignore
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        setIsSupported(true);
        const reco = new SpeechRecognition();
        reco.continuous = false; // Stop after one sentence/phrase for simple dictation
        reco.interimResults = true; // We could use this for realtime feedback, but let's stick to final for simplicity
        reco.lang = 'en-US';
        
        reco.onstart = () => setIsListening(true);
        reco.onend = () => setIsListening(false);
        reco.onresult = (event: any) => {
          let finalTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
              finalTranscript += event.results[i][0].transcript;
            }
          }
          if (finalTranscript) {
            onInput(finalTranscript);
          }
        };
        
        setRecognition(reco);
      }
    }
  }, [onInput]);

  const toggleListening = () => {
    if (!isSupported) {
      alert("Voice input is not supported in this browser.");
      return;
    }
    if (isListening) {
      recognition.stop();
    } else {
      recognition.start();
    }
  };

  if (!isSupported) return null;

  return (
    <button
      onClick={toggleListening}
      className={`rounded-full transition-all flex items-center justify-center flex-shrink-0 ${
        isListening 
          ? 'bg-red-500 text-white animate-pulse ring-2 ring-red-200' 
          : 'bg-slate-100 text-blue-600 hover:bg-slate-200'
      } ${compact ? 'p-2' : 'p-3'} ${className}`}
      title={isListening ? "Stop listening" : "Voice Input"}
      type="button"
    >
      {isListening ? <MicOff size={compact ? 16 : 20} /> : <Mic size={compact ? 16 : 20} />}
    </button>
  );
};

export default VoiceInput;