import React, { useState, useRef, useEffect } from 'react';
import { Send, Camera, Image as ImageIcon, X, Volume2, Square, Loader2, RefreshCw } from 'lucide-react';
import { Message, Subject, SolveModel } from '../types';
import { solveHomework, generateSpeech, base64ToUint8Array, pcmToAudioBuffer } from '../services/geminiService';
import MarkdownRenderer from './MarkdownRenderer';
import CameraCapture from './CameraCapture';
import VoiceInput from './VoiceInput';

interface SolverInterfaceProps {
  activeSubject: Subject;
}

const getQuickActions = (subjectId: string) => {
  switch (subjectId) {
    case 'math':
      return ['Solve step-by-step', 'Explain the formula', 'Graph this function', 'Check my answer'];
    case 'science':
      return ['Explain this concept', 'Balance equation', 'Key scientific principles', 'Real-world application'];
    case 'coding':
      return ['Debug this code', 'Explain the logic', 'Optimize complexity', 'Convert language'];
    case 'humanities':
      return ['Summarize key points', 'Historical context', 'Analyze the argument', 'Timeline of events'];
    default:
      return ['Summarize', 'Explain simply', 'Key takeaways', 'Quiz me'];
  }
};

const SolverInterface: React.FC<SolverInterfaceProps> = ({ activeSubject }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'model',
      text: `Hi! I'm your **${activeSubject.name}** AI tutor. I can solve problems, explain concepts, or review your work.`,
      timestamp: Date.now()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  // Audio Playback State
  const [playingMessageId, setPlayingMessageId] = useState<string | null>(null);
  const [isSynthesizingId, setIsSynthesizingId] = useState<string | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  // Cleanup audio on unmount
  useEffect(() => {
    return () => {
      stopAudio();
    };
  }, []);

  const handleSendMessage = async () => {
    if ((!inputText.trim() && !selectedImage) || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: inputText,
      image: selectedImage || undefined,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setSelectedImage(null);
    setIsLoading(true);

    const modelToUse = SolveModel.FLASH; 

    const responseText = await solveHomework(userMsg.text, userMsg.image, modelToUse);

    const modelMsg: Message = {
      id: (Date.now() + 1).toString(),
      role: 'model',
      text: responseText,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, modelMsg]);
    setIsLoading(false);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVoiceInput = (text: string) => {
    setInputText(prev => {
      const trimmed = prev.trim();
      return trimmed ? `${trimmed} ${text}` : text;
    });
  };

  const stopAudio = () => {
    if (sourceRef.current) {
      try {
        sourceRef.current.stop();
      } catch (e) {
        // Ignore errors if already stopped
      }
      sourceRef.current = null;
    }
    setPlayingMessageId(null);
  };

  const playMessageAudio = async (msgId: string, text: string) => {
    // If already playing this message, stop it
    if (playingMessageId === msgId) {
      stopAudio();
      return;
    }

    // Stop any currently playing audio
    stopAudio();

    setIsSynthesizingId(msgId);

    try {
      const base64Audio = await generateSpeech(text);
      if (!base64Audio) {
        throw new Error("No audio generated");
      }

      // Initialize Audio Context if needed
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }

      const audioCtx = audioCtxRef.current;
      // Resume context if suspended (browser policy)
      if (audioCtx.state === 'suspended') {
        await audioCtx.resume();
      }

      const pcmData = base64ToUint8Array(base64Audio);
      const audioBuffer = pcmToAudioBuffer(pcmData, audioCtx);

      const source = audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioCtx.destination);
      
      source.onended = () => {
        setPlayingMessageId(null);
        sourceRef.current = null;
      };

      sourceRef.current = source;
      source.start();
      setPlayingMessageId(msgId);
    } catch (err) {
      console.error("Playback failed", err);
      alert("Could not play audio. Please try again.");
    } finally {
      setIsSynthesizingId(null);
    }
  };

  const quickActions = getQuickActions(activeSubject.id);

  return (
    <div className="flex flex-col h-full bg-slate-50 relative">
      {isCameraOpen && (
        <CameraCapture 
          onCapture={(img) => {
            setSelectedImage(img);
            setIsCameraOpen(false);
          }}
          onClose={() => setIsCameraOpen(false)}
        />
      )}

      {/* Header for Mobile/Context */}
      <div className="lg:hidden h-14 bg-white border-b border-slate-100 flex items-center px-4 justify-between sticky top-0 z-10">
        <span className="font-semibold text-slate-800">{activeSubject.name}</span>
        <div className="w-2 h-2 rounded-full bg-green-500"></div>
      </div>

      {/* Chat Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 pb-48 scroll-smooth"
      >
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} animate-slide-up`}
          >
            <div className={`flex items-end gap-2 max-w-[90%] md:max-w-[75%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              
              {/* Avatar */}
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold shadow-sm ${
                msg.role === 'user' ? 'bg-slate-200 text-slate-600' : 'bg-primary-600 text-white'
              }`}>
                {msg.role === 'user' ? 'You' : 'AI'}
              </div>

              {/* Bubble */}
              <div className={`rounded-2xl p-4 shadow-sm relative group ${
                msg.role === 'user' 
                  ? 'bg-primary-600 text-white rounded-br-none' 
                  : 'bg-white border border-slate-100 text-slate-800 rounded-bl-none'
              }`}>
                {msg.image && (
                  <div className="mb-3 rounded-lg overflow-hidden border border-white/20">
                    <img src={msg.image} alt="User upload" className="max-h-60 w-auto object-cover" />
                  </div>
                )}
                {msg.role === 'model' ? (
                  <div className="prose-sm pb-2">
                    <MarkdownRenderer content={msg.text} />
                  </div>
                ) : (
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                )}

                {/* Read Aloud Button for AI messages */}
                {msg.role === 'model' && (
                  <div className="flex items-center justify-end mt-1 pt-2 border-t border-slate-50">
                    <button
                      onClick={() => playMessageAudio(msg.id, msg.text)}
                      disabled={isSynthesizingId === msg.id}
                      className={`p-1.5 rounded-full transition-all flex items-center gap-2 text-xs font-medium ${
                        playingMessageId === msg.id 
                          ? 'bg-primary-50 text-primary-600 ring-2 ring-primary-100' 
                          : 'text-slate-400 hover:bg-slate-50 hover:text-slate-600'
                      }`}
                      title="Read aloud"
                    >
                      {isSynthesizingId === msg.id ? (
                        <Loader2 size={14} className="animate-spin" />
                      ) : playingMessageId === msg.id ? (
                        <>
                          <Square size={12} fill="currentColor" />
                          <span>Stop</span>
                        </>
                      ) : (
                        <>
                          <Volume2 size={14} />
                          <span className="opacity-0 group-hover:opacity-100 transition-opacity">Read</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
            
            {/* Timestamp / Meta */}
            <div className={`mt-1 text-[10px] text-slate-400 px-12 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
               {msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : ''}
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start w-full px-10">
            <div className="bg-white border border-slate-100 rounded-2xl p-4 rounded-bl-none shadow-sm flex items-center gap-3">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
              </div>
              <span className="text-sm text-slate-500 font-medium">Thinking...</span>
            </div>
          </div>
        )}
      </div>

      {/* Input Area (Floating) */}
      <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6 z-20 pointer-events-none">
        <div className="max-w-4xl mx-auto pointer-events-auto">
          
          {/* Quick Actions (Scrollable) */}
          <div className="flex gap-2 overflow-x-auto no-scrollbar mb-3 pb-1 mask-linear-fade">
            {quickActions.map((action) => (
              <button
                key={action}
                onClick={() => setInputText(action)}
                className="whitespace-nowrap px-4 py-2 bg-white/90 backdrop-blur border border-slate-200 hover:border-primary-300 text-slate-600 hover:text-primary-600 text-xs font-semibold rounded-full shadow-sm transition-all flex-shrink-0"
              >
                {action}
              </button>
            ))}
          </div>

          {/* Image Preview */}
          {selectedImage && (
            <div className="flex items-center gap-3 mb-3 p-2 bg-white rounded-xl shadow-lg border border-slate-100 w-fit animate-fade-in">
              <img src={selectedImage} alt="Selected" className="h-12 w-12 object-cover rounded-lg" />
              <div className="flex flex-col">
                <span className="text-xs font-medium text-slate-700">Image attached</span>
                <span className="text-[10px] text-slate-400">Ready to send</span>
              </div>
              <button 
                onClick={() => setSelectedImage(null)}
                className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-red-500 rounded-full transition-colors ml-2"
              >
                <X size={14} />
              </button>
            </div>
          )}
          
          {/* Main Bar */}
          <div className="flex items-end gap-2 bg-white/90 backdrop-blur-md p-2 rounded-[2rem] shadow-[0_8px_30px_rgb(0,0,0,0.12)] border border-white/50">
            
            {/* Tools */}
            <div className="flex items-center gap-1 pl-1">
              <button 
                onClick={() => setIsCameraOpen(true)}
                className="p-3 bg-slate-100 text-slate-600 rounded-full hover:bg-slate-200 hover:text-primary-600 transition-colors"
                title="Snap Photo"
              >
                <Camera size={20} />
              </button>
              
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="p-3 bg-slate-100 text-slate-600 rounded-full hover:bg-slate-200 hover:text-primary-600 transition-colors"
                title="Upload Image"
              >
                <ImageIcon size={20} />
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*"
                  onChange={handleFileSelect}
                />
              </button>

              <VoiceInput onInput={handleVoiceInput} className="bg-slate-100 hover:bg-slate-200 text-slate-600" />
            </div>

            {/* Input Field */}
            <div className="flex-1 py-2 px-1">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder={`Ask ${activeSubject.name}...`}
                className="w-full bg-transparent border-none outline-none resize-none max-h-32 text-slate-800 placeholder-slate-400 text-sm md:text-base leading-relaxed"
                rows={1}
                style={{ minHeight: '44px' }}
              />
            </div>

            {/* Send Button */}
            <button 
              onClick={handleSendMessage}
              disabled={(!inputText.trim() && !selectedImage) || isLoading}
              className={`p-3 rounded-full flex-shrink-0 transition-all mb-1 mr-1 ${
                (!inputText.trim() && !selectedImage) || isLoading
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-primary-600 to-primary-500 text-white shadow-md hover:shadow-lg hover:scale-105 active:scale-95'
              }`}
            >
              {isLoading ? <RefreshCw size={20} className="animate-spin" /> : <Send size={20} />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SolverInterface;