import React from 'react';

interface MarkdownRendererProps {
  content: string;
  className?: string;
}

// A simplified Markdown renderer to avoid heavy dependencies while keeping formatting nice
const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content, className }) => {
  const renderContent = (text: string) => {
    // Split by newlines to handle paragraphs
    const lines = text.split('\n');
    
    return lines.map((line, index) => {
      let processedLine: React.ReactNode = line;
      
      // Basic Bold parsing (**text**)
      if (line.match(/\*\*(.*?)\*\*/)) {
        const parts = line.split(/(\*\*.*?\*\*)/);
        processedLine = parts.map((part, i) => {
          if (part.startsWith('**') && part.endsWith('**')) {
            return <strong key={i} className="font-bold text-slate-800">{part.slice(2, -2)}</strong>;
          }
          return part;
        });
      }

      // Headers (#, ##, ###)
      if (line.startsWith('### ')) return <h3 key={index} className="text-lg font-bold mt-3 mb-1 text-slate-800">{processedLine}</h3>;
      if (line.startsWith('## ')) return <h2 key={index} className="text-xl font-bold mt-4 mb-2 text-slate-900">{processedLine}</h2>;
      if (line.startsWith('# ')) return <h1 key={index} className="text-2xl font-bold mt-5 mb-3 text-slate-900">{processedLine}</h1>;

      // Bullet points
      if (line.trim().startsWith('- ')) {
        return (
          <div key={index} className="flex ml-4 mb-1">
            <span className="mr-2">•</span>
            <span>{line.replace('- ', '')}</span>
          </div>
        );
      }
      
      // Empty lines
      if (line.trim() === '') {
        return <div key={index} className="h-2" />;
      }

      return <p key={index} className="mb-1 leading-relaxed">{processedLine}</p>;
    });
  };

  return <div className={`text-sm md:text-base text-slate-700 ${className}`}>{renderContent(content)}</div>;
};

export default MarkdownRenderer;
