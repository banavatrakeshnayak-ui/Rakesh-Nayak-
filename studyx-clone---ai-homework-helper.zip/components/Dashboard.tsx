
import React from 'react';
import { Subject, User } from '../types';
import { SUBJECTS } from '../constants';
import { 
  Flame, 
  TrendingUp, 
  Clock, 
  ChevronRight, 
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface DashboardProps {
  onSelectSubject: (subject: Subject) => void;
  onOpenNotes: () => void;
  user: User;
}

const Dashboard: React.FC<DashboardProps> = ({ onSelectSubject, onOpenNotes, user }) => {
  return (
    <div className="h-full overflow-y-auto bg-slate-50 p-6 md:p-8 pb-24">
      <div className="max-w-5xl mx-auto space-y-8 animate-fade-in">
        
        {/* Welcome Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Hello, {user.name.split(' ')[0]}! 👋</h1>
            <p className="text-slate-500">Ready to crush your homework today?</p>
          </div>
          <div className="flex items-center gap-4 bg-white p-3 rounded-2xl shadow-sm border border-slate-100">
            <div className="flex items-center gap-2 text-orange-500 font-bold px-3 py-1 bg-orange-50 rounded-lg">
              <Flame size={18} />
              <span>3 Day Streak</span>
            </div>
            <div className="h-8 w-[1px] bg-slate-100"></div>
            <div className="flex items-center gap-2 text-primary-600 font-bold px-3 py-1 bg-primary-50 rounded-lg">
              <Sparkles size={18} />
              <span>120 XP</span>
            </div>
          </div>
        </div>

        {/* Quick Stats / Banner */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gradient-to-br from-primary-600 to-primary-800 rounded-2xl p-6 text-white col-span-1 md:col-span-2 relative overflow-hidden group cursor-pointer transition-transform hover:scale-[1.01]">
            <div className="absolute top-0 right-0 p-8 opacity-10 transform translate-x-10 -translate-y-10">
              <Sparkles size={140} />
            </div>
            <div className="relative z-10">
              <div className="inline-block px-3 py-1 bg-white/20 rounded-full text-xs font-medium mb-3 backdrop-blur-sm">
                Pro Tip
              </div>
              <h3 className="text-xl font-bold mb-2">Stuck on a Math problem?</h3>
              <p className="text-primary-100 mb-6 max-w-md">Snap a picture and get a step-by-step breakdown instantly. Our AI explains the 'Why', not just the 'How'.</p>
              <button 
                onClick={() => onSelectSubject(SUBJECTS.find(s => s.id === 'math') || SUBJECTS[0])}
                className="bg-white text-primary-700 px-5 py-2 rounded-lg font-semibold text-sm flex items-center gap-2 hover:bg-primary-50 transition-colors"
              >
                Solve Math <ArrowRight size={16} />
              </button>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-slate-800">Recent Activity</h3>
                <Clock size={18} className="text-slate-400" />
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0">
                    <TrendingUp size={14} />
                  </div>
                  <div className="truncate">
                    <p className="font-medium text-slate-700">Calculus Integration</p>
                    <p className="text-xs text-slate-400">2 hours ago</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center flex-shrink-0">
                    <TrendingUp size={14} />
                  </div>
                  <div className="truncate">
                    <p className="font-medium text-slate-700">Python Loops</p>
                    <p className="text-xs text-slate-400">Yesterday</p>
                  </div>
                </div>
              </div>
            </div>
            <button className="w-full mt-4 text-sm text-primary-600 font-medium hover:text-primary-700 text-left">
              View full history
            </button>
          </div>
        </div>

        {/* Subjects Grid */}
        <div>
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Sparkles className="text-primary-500" size={20} />
            Start Learning
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {SUBJECTS.map((subject) => {
              // Dynamic Icon rendering based on string name
              // Simplified for this example by using the same generic structure
              return (
                <button
                  key={subject.id}
                  onClick={() => onSelectSubject(subject)}
                  className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md hover:border-primary-200 transition-all text-left group"
                >
                  <div className={`w-12 h-12 rounded-xl ${subject.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    {/* Placeholder for icon, reusing styling */}
                    <div className="font-bold text-lg">{subject.name[0]}</div>
                  </div>
                  <h3 className="font-bold text-slate-900 mb-1 flex items-center justify-between">
                    {subject.name}
                    <ChevronRight size={16} className="text-slate-300 group-hover:text-primary-500 transform group-hover:translate-x-1 transition-all" />
                  </h3>
                  <p className="text-sm text-slate-500 line-clamp-2">
                    {subject.description}
                  </p>
                </button>
              );
            })}
            
            {/* Note Taker Card */}
            <button
              onClick={onOpenNotes}
              className="bg-gradient-to-br from-slate-800 to-slate-900 p-5 rounded-2xl shadow-sm hover:shadow-lg transition-all text-left group text-white relative overflow-hidden"
            >
              <div className="relative z-10">
                <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center mb-4 backdrop-blur-sm">
                  <div className="font-bold text-lg">N</div>
                </div>
                <h3 className="font-bold text-white mb-1 flex items-center justify-between">
                  AI Note Taker
                  <ChevronRight size={16} className="text-slate-400 group-hover:text-white transform group-hover:translate-x-1 transition-all" />
                </h3>
                <p className="text-sm text-slate-400 line-clamp-2">
                  Summarize lectures & docs instantly.
                </p>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
