import React from 'react';
import { HistoryItem } from '../types';
import { Clock, FileText, Calculator, Search, Trash2 } from 'lucide-react';

// Mock data generator since we don't have a real backend
const MOCK_HISTORY: HistoryItem[] = [
  { id: '1', type: 'solve', preview: 'Find the derivative of x^2 + 3x', subject: 'Mathematics', date: 'Just now' },
  { id: '2', type: 'note', preview: 'Summary of "The Great Gatsby" Chapter 1', date: '2 hours ago' },
  { id: '3', type: 'solve', preview: 'Explain Newton\'s Second Law', subject: 'Science', date: 'Yesterday' },
  { id: '4', type: 'solve', preview: 'Debug Python list comprehension', subject: 'Computer Science', date: 'Yesterday' },
  { id: '5', type: 'note', preview: 'History of the Roman Empire notes', date: '2 days ago' },
];

const HistoryInterface: React.FC = () => {
  return (
    <div className="h-full overflow-y-auto bg-slate-50 p-6 md:p-8 pb-24">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">History</h2>
            <p className="text-slate-500">Your recent study sessions</p>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={16} />
            <input 
              type="text" 
              placeholder="Search history..." 
              className="pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
        </div>

        <div className="space-y-4">
          {MOCK_HISTORY.map((item) => (
            <div key={item.id} className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow flex items-center justify-between group">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                  item.type === 'solve' ? 'bg-blue-50 text-blue-600' : 'bg-purple-50 text-purple-600'
                }`}>
                  {item.type === 'solve' ? <Calculator size={18} /> : <FileText size={18} />}
                </div>
                <div>
                  <h3 className="font-medium text-slate-800">{item.preview}</h3>
                  <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                    <span className="flex items-center gap-1">
                      <Clock size={12} /> {item.date}
                    </span>
                    {item.subject && (
                      <>
                        <span>•</span>
                        <span>{item.subject}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
              <button className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100">
                <Trash2 size={16} />
              </button>
            </div>
          ))}
          
          <div className="text-center py-8">
            <p className="text-sm text-slate-400">Showing last 5 items</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HistoryInterface;