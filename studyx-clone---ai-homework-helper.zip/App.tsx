
import React, { useState } from 'react';
import { 
  ScanLine, 
  NotebookPen, 
  History, 
  Menu, 
  GraduationCap,
  LayoutDashboard,
  LogOut
} from 'lucide-react';
import Dashboard from './components/Dashboard';
import SolverInterface from './components/SolverInterface';
import NotesInterface from './components/NotesInterface';
import HistoryInterface from './components/HistoryInterface';
import Login from './components/Login';
import { AppMode, Subject, User } from './types';
import { SUBJECTS } from './constants';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [mode, setMode] = useState<AppMode>(AppMode.DASHBOARD);
  const [activeSubject, setActiveSubject] = useState<Subject>(SUBJECTS[0]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Helper to handle navigation
  const navigateTo = (newMode: AppMode) => {
    setMode(newMode);
    setIsSidebarOpen(false);
  };

  const handleSubjectSelect = (subject: Subject) => {
    setActiveSubject(subject);
    navigateTo(AppMode.SOLVE);
  };

  const handleLogout = () => {
    setUser(null);
    setMode(AppMode.DASHBOARD);
  };

  if (!user) {
    return <Login onLogin={setUser} />;
  }

  return (
    <div className="h-screen w-full flex flex-col bg-slate-50 overflow-hidden font-sans text-slate-900">
      
      {/* Top Banner */}
      <div className="bg-slate-900 text-slate-200 text-xs py-1.5 text-center font-medium z-50 shadow-sm flex-shrink-0">
        Thanks for using app , created by Banavath Rakesh Nayak
      </div>

      <div className="flex-1 flex overflow-hidden w-full relative">
        {/* Sidebar (Mobile Overlay & Desktop Static) */}
        <div 
          className={`fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-slate-200 transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static flex flex-col ${
            isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
        >
          <div className="p-6 border-b border-slate-100 flex items-center gap-3">
            <div className="w-8 h-8 bg-primary-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-primary-600/30">
              <GraduationCap size={20} />
            </div>
            <span className="text-xl font-bold text-slate-900 tracking-tight">Home Work Helper</span>
          </div>

          <div className="p-4 flex-1 overflow-y-auto no-scrollbar">
            <div className="mb-8">
              <div className="space-y-1">
                <button
                  onClick={() => navigateTo(AppMode.DASHBOARD)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all font-medium text-sm ${
                    mode === AppMode.DASHBOARD ? 'bg-primary-50 text-primary-700' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <LayoutDashboard size={18} />
                  Dashboard
                </button>
                <button
                  onClick={() => navigateTo(AppMode.NOTES)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all font-medium text-sm ${
                    mode === AppMode.NOTES ? 'bg-primary-50 text-primary-700' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <NotebookPen size={18} />
                  AI Note Taker
                </button>
                <button
                  onClick={() => navigateTo(AppMode.HISTORY)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all font-medium text-sm ${
                    mode === AppMode.HISTORY ? 'bg-primary-50 text-primary-700' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <History size={18} />
                  History
                </button>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 px-3">Quick Subjects</h3>
              <div className="space-y-1">
                {SUBJECTS.map((sub) => (
                  <button
                    key={sub.id}
                    onClick={() => handleSubjectSelect(sub)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl transition-all text-sm group ${
                      activeSubject.id === sub.id && mode === AppMode.SOLVE
                        ? 'bg-slate-100 text-slate-900 font-medium' 
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <div className={`w-2 h-2 rounded-full transition-transform group-hover:scale-125 ${sub.color.split(' ')[0].replace('bg-', 'bg-')}`}></div>
                    {sub.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="p-4 border-t border-slate-100">
            <div className="bg-slate-900 rounded-xl p-4 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <ScanLine size={64} />
              </div>
              <h4 className="font-bold text-sm mb-1 relative z-10">Pro Plan</h4>
              <p className="text-xs text-slate-400 mb-3 relative z-10">Unlimited solutions & detailed explanations.</p>
              <button className="w-full py-2 bg-primary-600 hover:bg-primary-500 rounded-lg text-xs font-bold transition-colors relative z-10">
                Upgrade
              </button>
            </div>
          </div>
        </div>
        
        {/* Overlay for mobile sidebar */}
        {isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/20 backdrop-blur-sm z-30 lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col h-full relative bg-slate-50">
          {/* Header */}
          <header className="h-16 flex items-center justify-between px-4 lg:px-8 border-b border-slate-100 bg-white/80 backdrop-blur-md sticky top-0 z-20">
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setIsSidebarOpen(true)}
                className="p-2 -ml-2 text-slate-600 hover:bg-slate-100 rounded-lg lg:hidden"
              >
                <Menu size={20} />
              </button>
              <h1 className="text-lg font-bold text-slate-800">
                {mode === AppMode.SOLVE ? activeSubject.name : 
                 mode === AppMode.NOTES ? 'Note Taker' : 
                 mode === AppMode.HISTORY ? 'History' : 'Dashboard'}
              </h1>
            </div>
            <div className="flex items-center gap-3">
              <div className="hidden md:flex flex-col items-end">
                <span className="text-xs font-bold text-slate-700">{user.name}</span>
                <span className="text-[10px] text-slate-400">{user.email}</span>
              </div>
              <button 
                onClick={handleLogout}
                className="w-8 h-8 rounded-full overflow-hidden border-2 border-white shadow-sm hover:ring-2 hover:ring-primary-200 transition-all"
              >
                <img src={user.avatar} alt="Avatar" className="w-full h-full object-cover" />
              </button>
            </div>
          </header>

          {/* Dynamic View */}
          <main className="flex-1 overflow-hidden relative">
            {mode === AppMode.DASHBOARD && (
              <Dashboard 
                onSelectSubject={handleSubjectSelect}
                onOpenNotes={() => navigateTo(AppMode.NOTES)}
                user={user}
              />
            )}
            {mode === AppMode.SOLVE && (
              <SolverInterface activeSubject={activeSubject} />
            )}
            {mode === AppMode.NOTES && (
              <NotesInterface />
            )}
            {mode === AppMode.HISTORY && (
              <HistoryInterface />
            )}
          </main>
        </div>
      </div>
    </div>
  );
};

export default App;
