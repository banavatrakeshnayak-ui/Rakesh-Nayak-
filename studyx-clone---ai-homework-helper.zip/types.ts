
export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  image?: string; // Base64 string
  isThinking?: boolean;
  timestamp?: number;
}

export interface Note {
  id: string;
  title: string;
  originalText: string;
  summary: string;
  date: string;
  tags: string[];
}

export enum AppMode {
  DASHBOARD = 'dashboard',
  SOLVE = 'solve',
  NOTES = 'notes',
  HISTORY = 'history'
}

export interface Subject {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
}

export enum SolveModel {
  FLASH = 'gemini-2.5-flash', 
  PRO = 'gemini-3-pro-preview' 
}

export interface HistoryItem {
  id: string;
  type: 'solve' | 'note';
  preview: string;
  subject?: string;
  date: string;
}

export interface User {
  name: string;
  email: string;
  avatar: string;
  isPro?: boolean;
}