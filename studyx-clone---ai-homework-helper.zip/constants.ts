import { Subject } from './types';

export const APP_NAME = "Home Work Helper";

export const SUBJECTS: Subject[] = [
  { id: 'math', name: 'Mathematics', icon: 'Calculator', color: 'bg-blue-100 text-blue-600', description: 'Algebra, Calculus, Geometry & Statistics' },
  { id: 'science', name: 'Science', icon: 'FlaskConical', color: 'bg-emerald-100 text-emerald-600', description: 'Physics, Chemistry, Biology & Environmental' },
  { id: 'coding', name: 'Computer Science', icon: 'Code', color: 'bg-purple-100 text-purple-600', description: 'Python, Java, Web Dev & Algorithms' },
  { id: 'humanities', name: 'Humanities', icon: 'BookOpen', color: 'bg-amber-100 text-amber-600', description: 'History, Literature, Philosophy & Arts' },
  { id: 'general', name: 'General Helper', icon: 'Sparkles', color: 'bg-slate-100 text-slate-600', description: 'General Knowledge, Logic & Planning' },
];

export const SYSTEM_INSTRUCTION_SOLVER = `
You are an expert AI Homework Helper. 
1. Solve the user's problem step-by-step.
2. For Math/Science: Show the work clearly. Explain formulas used.
3. For Humanities/Language: Provide context and detailed explanations.
4. If an image is provided, analyze it carefully to extract the problem.
5. Keep the tone encouraging, educational, and professional.
6. Use Markdown for formatting (bold, bullet points, code blocks, LaTeX for math if needed but keep it simple).
`;

export const SYSTEM_INSTRUCTION_NOTES = `
You are an expert Study Note Taker.
1. Summarize the provided text into clear, concise study notes.
2. Use bullet points, bold key terms, and create a "Key Takeaways" section.
3. Organize content logically with headers.
4. If appropriate, generate a few "Quiz Questions" at the end to test understanding.
`;