import { GoogleGenAI, GenerateContentResponse, Modality } from "@google/genai";
import { SYSTEM_INSTRUCTION_SOLVER, SYSTEM_INSTRUCTION_NOTES } from '../constants';
import { SolveModel } from '../types';

const getClient = () => {
  const apiKey = typeof process !== 'undefined' ? process.env.API_KEY : '';
  return new GoogleGenAI({ apiKey });
};

export const solveHomework = async (
  prompt: string, 
  imageBase64: string | undefined, 
  modelName: SolveModel = SolveModel.FLASH
): Promise<string> => {
  const ai = getClient();
  
  try {
    const parts: any[] = [];
    
    if (imageBase64) {
      // Remove header if present (data:image/jpeg;base64,)
      const cleanBase64 = imageBase64.split(',')[1] || imageBase64;
      parts.push({
        inlineData: {
          mimeType: 'image/jpeg',
          data: cleanBase64
        }
      });
    }

    if (prompt) {
      parts.push({ text: prompt });
    }

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: modelName,
      contents: { parts },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION_SOLVER,
        temperature: 0.4, 
      }
    });

    return response.text || "I couldn't generate a solution. Please try again.";
  } catch (error) {
    console.error("Gemini Solve Error:", error);
    return "Sorry, I encountered an error while solving this problem. Please check your connection or try a different image.";
  }
};

export const summarizeNotes = async (text: string): Promise<string> => {
  const ai = getClient();
  
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: text,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION_NOTES,
        temperature: 0.5,
      }
    });

    return response.text || "Could not generate summary.";
  } catch (error) {
    console.error("Gemini Note Error:", error);
    return "Failed to summarize notes. Please try again.";
  }
};

export const generateSpeech = async (text: string): Promise<string | null> => {
  const ai = getClient();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: { parts: [{ text }] },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
  } catch (error) {
    console.error("TTS Error:", error);
    return null;
  }
};

// Audio Helpers
export const base64ToUint8Array = (base64: string): Uint8Array => {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};

export const pcmToAudioBuffer = (
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1
): AudioBuffer => {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
};